#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "Lexer.h"
#include "StringAutomaton.h"
#include "CommentAutomaton.h"
#include "IdentifierAutomaton.h"
#include "UndefinedAutomaton.h"

using namespace std;

int main(int argc, const char* argv[]) {
    if (argc != 2) {
        cout << "Usage:" << endl;
        cout << "    ./lab1 [infile]" << endl;
        return 0;
    }
    
    string filename = argv[1];
    ifstream f(filename);
    string input;
    if (f) {
       ostringstream ss;
       ss << f.rdbuf();
       input = ss.str();
    } else {
        cout << " Error: " << filename << ": No such file or directory" << endl;
        return 0;
    }
    
    Lexer* lexer = new Lexer();
    lexer->Run(input);
    delete lexer;
    
    return 0;
}
